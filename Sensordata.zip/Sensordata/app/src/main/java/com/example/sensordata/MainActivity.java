package com.example.sensordata;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;



public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        final SwipeRefreshLayout mSwipeRefreshLayout = findViewById(R.id.swiperefresh);

        mSwipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        Log.i("TAG", "onRefresh called from SwipeRefreshLayout");

                        // This method performs the actual data-refresh operation.
                        // The method calls setRefreshing(false) when it's finished.
                        myUpdateOperation();
                        mSwipeRefreshLayout.setRefreshing(false);
                    }
                }
        );

        final ListView listView = (ListView) findViewById(R.id.list);
        final  ArrayList<String> sensorList = new ArrayList<String>();
        List<Sensor> sensors = ((SensorManager) getSystemService(
                Context.SENSOR_SERVICE)).getSensorList(Sensor.TYPE_ALL);
        for (Sensor sensor : sensors) {
            sensorList.add(sensor.getName());
        }
        ArrayAdapter sensorAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, sensorList);
        listView.setAdapter(sensorAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (sensorList.get(position).contains("Orientation")) {
                    Intent intent1= new Intent(getApplicationContext(),Main3Activity.class);
                    startActivity(intent1);

                }  else {


                    //Toast.makeText(getApplicationContext(),sensorList.get(position), Toast.LENGTH_SHORT).show();


                    Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                    intent.putExtra("sensorname", sensorList.get(position));
                    startActivity(intent);
                }

                                            }
                                        }
        );
    }

    void myUpdateOperation() {
        Toast.makeText(this, "Refresh", Toast.LENGTH_SHORT).show();
    }





}


