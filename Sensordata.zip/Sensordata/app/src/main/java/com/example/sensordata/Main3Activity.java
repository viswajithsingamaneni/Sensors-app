package com.example.sensordata;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent1 = getIntent();}

    public void checkOrientation(View view){
        int orientation = getResources()
                .getConfiguration().orientation;
        switch (orientation) {
            case Configuration.ORIENTATION_LANDSCAPE:
                TextView textview2 =  findViewById(R.id.textView2);
                String name2 = "ORIENTATION LANDSCAPE";
                textview2.setText(name2);
                break;
            case Configuration.ORIENTATION_PORTRAIT:
                TextView textview3 = findViewById(R.id.textView2);
                String name3 = "ORIENTATION PORTRAIT";
                textview3.setText(name3);
                break;
            case Configuration.ORIENTATION_UNDEFINED:
                TextView textview4 =  findViewById(R.id.textView2);
                String name4 = "ORIENTATION UNDEFINED";
                textview4.setText(name4);
                break;
        }
    }
    }

