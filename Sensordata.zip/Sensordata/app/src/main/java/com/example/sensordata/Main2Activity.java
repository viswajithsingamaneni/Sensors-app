package com.example.sensordata;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    private SensorManager mSensorManager;
    private Sensor mSensor;
    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        String name = intent.getStringExtra("sensorname");
        Toast.makeText(this, name, Toast.LENGTH_SHORT).show();
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mTextView = (TextView) findViewById(R.id.textView);
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


        if (name.contains("Accelerometer")) {
            if (name.contains("Uncalibrated")) {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER_UNCALIBRATED);
            } else {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            }
        }

        if (name.contains("Gyroscope")) {
            if (name.contains("Uncalibrated")) {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE_UNCALIBRATED);
            } else {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            }
        }

        if (name.contains("Magnetic")) {
            if (name.contains("Uncalibrated")) {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED);
            } else {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            }
        }

        if (name.contains("Light")) {
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        }

        if (name.contains("Proximity")) {
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        }



        if (name.contains("Gravity")) {
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        }

        if (name.contains("Rotation Vector")) {
            if (name.contains("Game")) {

                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
            } else if (name.contains("Geometric")) {

                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR);
            } else {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            }


        }

        if (name.contains("Step")) {
            if (name.contains("Detector")) {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            } else if (name.contains("Counter")) {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            }
        }

        if (name.contains("Linear Acceleration")) {
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        }

    }




    private SensorEventListener mSensorListener = new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent event) {
                    if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        mTextView.setText(String.valueOf(total)+ " m/s^2"+ "\n X-Axis:  " + String.valueOf(x)+ "\n Y-Axis:  " + String.valueOf(y)+ "\n Z-Axis:  " + String.valueOf(z) );
                    }else if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER_UNCALIBRATED) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        float x1 = event.values[3];
                        float y1 = event.values[4];
                        float z1 = event.values[5];
                        double total1 = Math.sqrt(x1 * x1 + y1 * y1 + z1 * z1);
                        mTextView.setText("\nwithout bias compensation" + String.valueOf(total)+ " m/s^2"+ "\n X-Axis:  " + String.valueOf(x)+ "\n Y-Axis:  " + String.valueOf(y)+ "\n Z-Axis:  " + String.valueOf(z) + "\nwith estimated bias compensation:\n" + String.valueOf(total1)+ " m/s^2"+ "\n X-Axis:  " + String.valueOf(x1)+ "\n Y-Axis:  " + String.valueOf(y1)+ "\n Z-Axis:  " + String.valueOf(z1) );
                    }else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        mTextView.setText(String.valueOf(total)+ " rad/s"+ "\n X-Axis:  " + String.valueOf(x)+ "\n Y-Axis:  " + String.valueOf(y)+ "\n Z-Axis:  " + String.valueOf(z) );
                    }else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE_UNCALIBRATED) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        float x1 = event.values[3];
                        float y1 = event.values[4];
                        float z1 = event.values[5];
                        double total1 = Math.sqrt(x1 * x1 + y1 * y1 + z1 * z1);
                        mTextView.setText("without drift compensation:\n" + String.valueOf(total)+ " rad/s"+ "\n X-Axis:  " + String.valueOf(x)+ " rad/s \n Y-Axis:  " + String.valueOf(y)+ " rad/s \n Z-Axis:  " + String.valueOf(z) + "\nwith estimated drift compensation:\n" + String.valueOf(total1)+ " rad/s"+ "\n X-Axis:  " + String.valueOf(x1)+ "rad/s \n Y-Axis:  " + String.valueOf(y1)+ "rad/s \n Z-Axis:  " + String.valueOf(z1) );
                    }else if (event.sensor.getType() == Sensor.TYPE_GRAVITY) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        mTextView.setText(String.valueOf(total)+ " m/s^s"+ "\n X-Axis:  " + String.valueOf(x)+ "m/s^2 \n Y-Axis:  " + String.valueOf(y)+ "m/s^2 \n Z-Axis:  " + String.valueOf(z) );
                    }else if (event.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        mTextView.setText(String.valueOf(total)+ " m/s^s"+ "\n X-Axis:  " + String.valueOf(x)+ "m/s^2 \n Y-Axis:  " + String.valueOf(y)+ "m/s^2 \n Z-Axis:  " + String.valueOf(z) );
                    }else if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        float c = event.values[3];
                        mTextView.setText("cos(θ/2): " + String.valueOf(c) + "\n x * sin(θ/2):  " + String.valueOf(x)+ " \n y * sin(θ/2):  " + String.valueOf(y)+ "\n z * sin(θ/2):  " + String.valueOf(z) );
                    }else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        mTextView.setText(String.valueOf(total)+ "uT" + "\n X-Axis:  " + String.valueOf(x)+ " uT \n Y-Axis:  " + String.valueOf(y)+ " uT\n Z-Axis:  " + String.valueOf(z) );
                    } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED) {

                        float x = event.values[0];
                        float y = event.values[1];
                        float z = event.values[2];
                        double total = Math.sqrt(x * x + y * y + z * z);
                        float x1 = event.values[3];
                        float y1 = event.values[4];
                        float z1 = event.values[5];
                        double total1 = Math.sqrt(x1 * x1 + y1 * y1 + z1 * z1);
                        mTextView.setText("uncalibrated:\n" + String.valueOf(total)+ " uT"+ "\n X-Axis:  " + String.valueOf(x)+ " uT \n Y-Axis:  " + String.valueOf(y)+ " uT \n Z-Axis:  " + String.valueOf(z) + "\nbiased" + String.valueOf(total1)+ " uT"+ "\n X-Axis:  " + String.valueOf(x1)+ "uT \n Y-Axis:  " + String.valueOf(y1)+ " uT\n Z-Axis:  " + String.valueOf(z1) );
                    } else if (event.sensor.getType() == Sensor.TYPE_LIGHT){
                        mTextView.setText(String.valueOf(event.values[0]) + "lx");
                    } else if (event.sensor.getType() == Sensor.TYPE_PRESSURE){
                        mTextView.setText(String.valueOf(event.values[0]) + "hPa");
                    } else if (event.sensor.getType() == Sensor.TYPE_PROXIMITY){
                        mTextView.setText(String.valueOf(event.values[0]) + "cm");
                    } else {
                        mTextView.setText(String.valueOf(event.values[0]));
                    }
                }
                @Override
                public void onAccuracyChanged(Sensor sensor, int
                        accuracy) {
//Nothing to do
                }
            };
    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(mSensorListener, mSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(mSensorListener);
    }
}
